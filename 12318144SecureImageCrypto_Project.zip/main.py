
import tkinter as tk
from tkinter import filedialog, messagebox
from PIL import Image, ImageTk
from cryptography.fernet import Fernet
import os

class ImageCryptoApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Secure Image Transmission")
        self.filename = ''
        self.key = Fernet.generate_key()
        self.cipher = Fernet(self.key)

        self.label = tk.Label(root, text="Upload an Image")
        self.label.pack()

        self.img_label = tk.Label(root)
        self.img_label.pack()

        tk.Button(root, text="Upload Image", command=self.upload_image).pack()
        tk.Button(root, text="Encrypt", command=self.encrypt_image).pack()
        tk.Button(root, text="Decrypt", command=self.decrypt_image).pack()

    def upload_image(self):
        self.filename = filedialog.askopenfilename(filetypes=[("Image files", "*.jpg *.png *.jpeg")])
        if self.filename:
            img = Image.open(self.filename)
            img = img.resize((300, 300))
            self.tk_img = ImageTk.PhotoImage(img)
            self.img_label.configure(image=self.tk_img)

    def encrypt_image(self):
        if not self.filename:
            messagebox.showerror("Error", "No image selected!")
            return
        with open(self.filename, 'rb') as file:
            data = file.read()
        encrypted_data = self.cipher.encrypt(data)
        enc_filename = os.path.splitext(self.filename)[0] + "_encrypted.img"
        with open(enc_filename, 'wb') as enc_file:
            enc_file.write(encrypted_data)
        messagebox.showinfo("Success", f"Image Encrypted.\nSaved as {enc_filename}")
        with open("secret.key", "wb") as key_file:
            key_file.write(self.key)

    def decrypt_image(self):
        enc_file = filedialog.askopenfilename(title="Select Encrypted Image", filetypes=[("Encrypted files", "*.img")])
        if not enc_file:
            return
        try:
            with open("secret.key", "rb") as key_file:
                self.key = key_file.read()
            self.cipher = Fernet(self.key)
            with open(enc_file, 'rb') as file:
                encrypted_data = file.read()
            decrypted_data = self.cipher.decrypt(encrypted_data)
            dec_file = "decrypted_image.png"
            with open(dec_file, 'wb') as file:
                file.write(decrypted_data)
            img = Image.open(dec_file)
            img = img.resize((300, 300))
            self.tk_img = ImageTk.PhotoImage(img)
            self.img_label.configure(image=self.tk_img)
            messagebox.showinfo("Success", f"Image Decrypted and Saved as {dec_file}")
        except Exception as e:
            messagebox.showerror("Decryption Failed", str(e))

if __name__ == "__main__":
    root = tk.Tk()
    app = ImageCryptoApp(root)
    root.mainloop()
